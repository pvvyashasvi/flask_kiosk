# flask-realtime-face-detection-opencv-python
realtime face detection using python and opencv , webcam should be enabled to get it working.

#How to use it

1.Install all the dependencies it has 
: opencv 2.x version
: python 2.7
: flask

2.Now train the algorithm by executing create_data.py file

3.After the data has been trained, you can execute face_recognise.py to make it run

4.For using it on a web based interface, run , python app.py and open your localhost
